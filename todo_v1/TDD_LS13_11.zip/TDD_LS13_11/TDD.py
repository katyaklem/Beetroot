import datetime

class Book:
	items = []

	def __init__(self, title, published, author):
		self.title = title
		self.author = author
		self.published = published
		Book.items.append(self)

	def __str__(self):
		return f'{self.author}\'s {self.title}'

	def __repr__(self):
		return f'{self.author}\'s {self.title}'

	def __eq__(self, other):
		return self.author == other.author and self.title == other.title

	def __hash__(self):
		return hash((self.title, self.author))	

	@classmethod
	def find_by_title(cls, title):
		find_books = []
		for item in cls.items:
			if title.lower() == item.title.lower():
				find_books.append(item)
		return find_books

	@classmethod
	def find_by_author(cls, author):
		find_books = []
		for item in cls.items:
			if author.lower() in item.author.lower():
				find_books.append(item)
		return find_books

	



first_book = Book('Dune', datetime.date(1965, 8, 1), 'Frank Herbert')
second_book = Book('Dune', datetime.date.today(), 'Frank Herbert')
third_book = Book('Children of Dune', datetime.date(1976, 4, 1), 'Frank Herbert')
fourth_book = Book('Dune', datetime.date(1965, 8, 1), 'Brian Herbert')
print(first_book == second_book)
print(first_book == third_book)
print(first_book == fourth_book)

'''
	def test_book_hash(self):
        new_book = Book('Dune', datetime.date(1965, 8, 1), 'Frank Herbert')
        self.assertEqual(hash(new_book), hash(('Dune', 'Frank Herbert')))

    def test_published_after(self):
        first_book = Book('Dune', datetime.date(1965, 8, 1), 'Frank Herbert')
        second_book = Book('The Lord of the Rings', datetime.date(1954, 7, 29), 'J. R. R. Tolkien')
        book_found = Book.published_after(year=1960)
        self.assertEqual(book_found, [first_book])


    def __eq__(self, other):
        return self.age == other.age

    def __ne__(self, other):
        return self.age != other.age

    def __lt__(self, other):
        return self.age < other.age

    def __le__(self, other):
        return self.age <= other.age

    def __gt__(self, other):
        return self.age > other.age

    def __ge__(self, other):
        return self.age >= other.age

    def test_book_hash(self):
        new_book = Book('Dune', datetime.date(1965, 8, 1), 'Frank Herbert')
        self.assertEqual(hash(new_book), hash(('Dune', 'Frank Herbert')))

    def test_published_after(self):
        first_book = Book('Dune', datetime.date(1965, 8, 1), 'Frank Herbert')
        second_book = Book('The Lord of the Rings', datetime.date(1954, 7, 29), 'J. R. R. Tolkien')
        book_found = Book.published_after(year=1960)
        self.assertEqual(book_found, [first_book])
'''


class Movie:
	pass